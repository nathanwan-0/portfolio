from Crypto.PublicKey import RSA

def generate_keypair():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

def save_key_to_file(filename, key):
    with open(filename, 'wb') as f:
        f.write(key)

def generate_keys_for_clients():
    # Generating the server key pair
    server_private_key, server_public_key = generate_keypair()
    save_key_to_file('server_private.pem', server_private_key)
    save_key_to_file('server_public.pem', server_public_key)

    # Generating keys for 5 known clients
    for i in range(1, 6):
        client_private_key, client_public_key = generate_keypair()
        save_key_to_file(f'client{i}_private.pem', client_private_key)
        save_key_to_file(f'client{i}_public.pem', client_public_key)

if __name__ == "__main__":
    generate_keys_for_clients()
    print("Server and client keys have been generated.")
