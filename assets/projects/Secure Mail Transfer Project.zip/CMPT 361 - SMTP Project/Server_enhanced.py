import socket
import json
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from Crypto.Hash import SHA256
import os
import sys
from datetime import datetime

# Load user credentials
with open('user_pass.json') as user_file:
    user_data = json.load(user_file)

# Store emails
client_inboxes = {user: [] for user in user_data}


# Load RSA private key (server's private key)
def load_rsa_key(filename):
    with open(filename, 'rb') as f:
        key_data = f.read()
    return RSA.import_key(key_data)


def encrypt_aes(data, aes_key):
    cipher = AES.new(aes_key, AES.MODE_ECB)
    if not data:
        print("Error: Empty data being encrypted!")
        return b""
    return cipher.encrypt(pad(data.encode(), AES.block_size))


def decrypt_aes(data, aes_key):
    if not data:
        print("Error: Empty data being decrypted!")
        return ""
    cipher = AES.new(aes_key, AES.MODE_ECB)
    try:
        decrypted_data = unpad(cipher.decrypt(data), AES.block_size)
        return decrypted_data.decode()
    except ValueError:
        print("Error: Padding is incorrect or data is empty.")
        return ""


def decrypt_rsa(data, private_key):
    """Decrypt data with the RSA private key."""
    try:
        #print("Starting RSA decryption...")
        cipher = PKCS1_OAEP.new(private_key)
        decrypted_data = cipher.decrypt(data).decode()
        #print(f"RSA Decrypted Data: {decrypted_data}")  # Print decrypted data for verification
        return decrypted_data
    except Exception as e:
        print(f"RSA Decryption Error: {e}")
        return None

def encrypt_rsa(data, public_key):
    cipher = PKCS1_OAEP.new(public_key)
    encrypted_data = cipher.encrypt(data)  # Encrypt data (now in bytes)
    return encrypted_data


def save_email_to_file(email, sender):
    """Save email content to a text file with proper formatting."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    email_content = f"""From: {sender}
To: {', '.join(email['destinations'])}
Time and Date: {timestamp}
Title: {email['title']}
Content Length: {len(email['message'])}
Contents:
{email['message']}
"""
    for dest in email['destinations']:
        filename = f"{dest}_{email['title']}.txt"
        dest_dir = dest
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
        with open(os.path.join(dest_dir, filename), 'w') as f:
            f.write(email_content)


def load_emails_from_files():
    """Load emails from .txt files into memory"""
    for username in os.listdir():
        if os.path.isdir(username):  # Check if it's a directory
            for filename in os.listdir(username):
                if filename.endswith('.txt'):
                    with open(os.path.join(username, filename), 'r') as f:
                        email_content = f.read()
                    email_parts = email_content.split("\n")
                    email_data = {
                        'sender': email_parts[0].split(": ")[1],
                        'destinations': email_parts[1].split(": ")[1].split(", "),
                        'timestamp': email_parts[2].split(": ")[1],
                        'title': email_parts[3].split(": ")[1],
                        'message': "\n".join(email_parts[6:])
                    }
                    if not any(email['title'] == email_data['title'] for email in client_inboxes[username]):
                        client_inboxes[username].append(email_data)  # Add the email if not a duplicate


def hash_data(data):
    """Generate an SHA-256 hash of the data."""
    hasher = SHA256.new()
    hasher.update(data.encode())
    return hasher.digest()


def verify_hash(data, expected_hash):
    """Verify that the hash matches the data."""
    return hash_data(data) == expected_hash


def handle_client(client_socket):
    # Load the server private key to decrypt incoming RSA data
    private_key = load_rsa_key('server_private.pem')

    # Receive encrypted username and password
    encrypted_data = client_socket.recv(256)
    if len(encrypted_data) == 0:
        print("No data received from client.")
        client_socket.close()
        return

    try:
        # Decrypt the received username and password
        decrypted_credentials = decrypt_rsa(encrypted_data, private_key)
        if decrypted_credentials is None:
            print("Decryption failed!")
            client_socket.send(b"Error: Decryption failed")
            client_socket.close()
            return

        username, password = decrypted_credentials.split(' ')

        # Check credentials
        if username in user_data and user_data[username] == password:
            client_socket.send(b"\x00")
            print(f"Connection Accepted and Symmetric Key Generated for client: {username}")

            # Load the client's public key
            client_public_key = load_rsa_key(f"{username}_public.pem")

            # Generate AES key
            aes_key = get_random_bytes(32)  # AES-256 key

            # Encrypt the AES key using the client's public key
            encrypted_aes_key = encrypt_rsa(aes_key, client_public_key)

            # Generate and send hash of AES key
            aes_key_hash = hash_data(str(aes_key))
            client_socket.send(aes_key_hash + encrypted_aes_key)

            # Handle menu options
            while True:
                #load_emails_from_files()
                #print("loaded")
                # Encrypt the menu message with AES key
                menu_message = '''Select the operation:
1) Create and send an email
2) Display the inbox list
3) Display the email contents
4) Terminate the connection
'''
                #print("test23")
                encrypted_menu = encrypt_aes(menu_message, aes_key)
                client_socket.send(encrypted_menu)

                # Receive client choice and decrypt it
                encrypted_choice = client_socket.recv(16)
                if len(encrypted_choice) == 0:
                    print("No data received for choice.")
                    break
                choice = decrypt_aes(encrypted_choice, aes_key)

                if choice == '4':
                    print(f"Terminating connection with {username}")
                    client_socket.send(b"Terminating connection with client.")
                    client_socket.close()
                    break

                elif choice == '1':
                    # Handle email sending (Save email to inbox)
                    email_data = client_socket.recv(1024)
                    email = eval(decrypt_aes(email_data, aes_key))  # Convert string back to dict
                    for dest in email['destinations']:
                        if dest in client_inboxes:
                            client_inboxes[dest].append(email)
                    # Log the email metadata
                    content_length = len(email['message'])
                    print(f"An email from {username} is sent to {','.join(email['destinations'])} has a content length of {content_length} .")
                    save_email_to_file(email, username)  # Save email to destination directories

                elif choice == '2':
                    # Display inbox list
                    load_emails_from_files()
                    inbox = client_inboxes[username]
                    inbox_list = "\n"
                    for i, email in enumerate(inbox, 1):
                        inbox_list += f"{i} {email['sender']} {email['timestamp']} {email['title']}\n"
                    client_socket.send(encrypt_aes(inbox_list, aes_key))


                elif choice == '3':  # Display email contents
                    # Receive the index for the email to display, which is in the format '3:{index}'
                    encrypted_index = client_socket.recv(1024)
                    index_data = decrypt_aes(encrypted_index, aes_key)
                    # Extract the index from the '3:{index}' string
                    try:
                        action, email_index = index_data.split(":")
                        email_index = int(email_index) - 1  # Convert to 0-based index
                    except ValueError:
                        client_socket.send(encrypt_aes("Invalid index received.", aes_key))
                        continue
                    # Ensure the index is within the range of available emails
                    if 0 <= email_index < len(client_inboxes[username]):
                        email = client_inboxes[username][email_index]
                        email_contents = f"""From: {email['sender']}
To: {', '.join(email['destinations'])}
Time and Date Received: {email['timestamp']}
Title: {email['title']}
Content Length: {len(email['message']) - 1}
Contents:
{email['message']}
                """
                        client_socket.send(encrypt_aes(email_contents, aes_key))
                    else:
                        client_socket.send(encrypt_aes("Invalid email index.", aes_key))
        else:
            client_socket.send(b"Invalid username or password")
            client_socket.close()
    except Exception as e:
        print(f"Error handling credentials: {e}")
        client_socket.send(b"Error: Decryption failed")
        client_socket.close()


def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 13000))
    server_socket.listen(5)
    print("The server is ready to accept connections")

    # Load emails from .txt files into memory at server startup
    load_emails_from_files()

    while True:
        client_socket, _ = server_socket.accept()  # _ since we no longer need client_address
        pid = os.fork()
        if pid == 0:
            server_socket.close()
            handle_client(client_socket)
            sys.exit(0)


if __name__ == "__main__":
    main()
