import socket
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Util.Padding import pad, unpad
import sys


def load_rsa_key(filename):
    """Load an RSA key from a PEM file."""
    with open(filename, 'rb') as f:
        key_data = f.read()
    return RSA.import_key(key_data)


def encrypt_rsa(data, public_key):
    """Encrypt data with RSA using the public key."""
    cipher = PKCS1_OAEP.new(public_key)
    encrypted_data = cipher.encrypt(data.encode())
    return encrypted_data


def decrypt_rsa(data, private_key):
    """Decrypt RSA encrypted data using the private key."""
    cipher = PKCS1_OAEP.new(private_key)
    decrypted_data = cipher.decrypt(data)
    if isinstance(decrypted_data, bytes):
        return decrypted_data
    else:
        return decrypted_data.decode()


def encrypt_aes(data, aes_key):
    """Encrypt data with AES using ECB mode."""
    cipher = AES.new(aes_key, AES.MODE_ECB)
    encrypted_data = cipher.encrypt(pad(data.encode(), AES.block_size))
    return encrypted_data


def decrypt_aes(data, aes_key):
    """Decrypt AES encrypted data using ECB mode."""
    cipher = AES.new(aes_key, AES.MODE_ECB)
    try:
        #print(f"Raw received data (before decryption): {data.hex()}")
        decrypted_data = unpad(cipher.decrypt(data), AES.block_size)
        return decrypted_data.decode()
    except ValueError:
        print("Error: Padding is incorrect or data is empty.")
        return ""


def main():
    server_ip = input("Enter the server IP or name: ")
    server_port = 13000
    client_username = input("Enter your username: ")
    client_password = input("Enter your password: ")

    # Load the server public key for RSA encryption
    server_public_key = load_rsa_key('server_public.pem')

    # Connect to server
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((server_ip, server_port))

    # Encrypt username and password with RSA using server's public key
    credentials = f"{client_username} {client_password}"
    encrypted_credentials = encrypt_rsa(credentials, server_public_key)
    client_socket.send(encrypted_credentials)

    response = client_socket.recv(47).decode()
    print(f"{response}")

    if response == "Invalid username or password":
        print("\nTerminating.")
        client_socket.close()
        sys.exit(1)

    # Receive the encrypted AES key from the server
    encrypted_aes_key = client_socket.recv(256)

    # Load the client's private key for decryption
    client_private_key = load_rsa_key(f"{client_username}_private.pem")

    aes_key = decrypt_rsa(encrypted_aes_key, client_private_key)

    # Now secure communication with AES key
    while True:
        menu = decrypt_aes(client_socket.recv(144), aes_key)
        print(f"{menu}")

        choice = input("choice: ")
        encrypted_choice = encrypt_aes(choice, aes_key)
        client_socket.send(encrypted_choice)

        if choice == '1':  # Create and send an email
            destinations = input("Enter destinations (separated by ;): ")
            title = input("Enter title: ")
            load_from_file = input("Would you like to load contents from a file?(Y/N): ")

            if load_from_file.lower() == 'y':
                filename = input("Enter filename: ")
                try:
                    with open(filename, 'r') as file:
                        message_contents = file.read()
                except FileNotFoundError:
                    print("File not found!")
                    continue
            else:
                message_contents = input("Enter message contents: ")

            # Constructing email and sending
            email = {
                'destinations': destinations.split(';'),
                'title': title,
                'message': message_contents
            }
            # Send the email content to the server
            client_socket.send(encrypt_aes(str(email), aes_key))
            print("The message is sent to the server.")

        elif choice == '2':  # Display inbox list
            # Receive the inbox list from the server
            encrypted_inbox_list = client_socket.recv(1024)
            inbox_list = decrypt_aes(encrypted_inbox_list, aes_key)
            print(f"Index\tFrom\tDateTime\tTitle{inbox_list}")

        elif choice == '3':  # Display email contents
            email_index = input("Enter the email index you wish to view: ")
            client_socket.send(encrypt_aes(f'3:{email_index}', aes_key))

            encrypted_email_contents = client_socket.recv(1024)
            email_contents = decrypt_aes(encrypted_email_contents, aes_key)
            print(f"\n{email_contents}")

        elif choice == '4':  # Terminate the connection
            print("The connection is terminated with the server.")
            client_socket.close()
            break


if __name__ == "__main__":
    main()
